"""
WolterWavelet2021Raw Trainer.

Original Wolter et al. 2022 architecture without modifications.
Uses WaveletPacketCNN with 512 -> 1 classifier (no embedding layer).

Preserved exactly from WaveletsRawModelRawInput/trainer_WaveletsRawModelRawInput.py.
"""
import torch
import torch.nn as nn
from models.base.base_model import BaseModel, init_weights
from .wavelet_cnn import WaveletPacketCNN
from .wavelet_utils import compute_wavelet_packet_coeffs, log_scale_packets


class WolterWaveletRawTrainer(BaseModel):
    """
    Wavelet-Packet DeepFake Detection Trainer
    Based on: Wolter et al. "Wavelet-Packets for Deepfake Image Analysis and Detection"
    Machine Learning, ECML PKDD 2022 Journal Track

    Original architecture without modifications.

    GPU wavelet mode:
        When ``opt.wavelet_backend == 'gpu'``, the DataLoader delivers
        raw RGB tensors (3 channels) and this trainer computes wavelet
        packets on GPU for the entire batch inside ``set_input`` using
        the batched ``GPUWaveletBackend``.  This keeps DataLoader workers
        busy with fast I/O while the GPU handles both wavelets and training.
    """

    def name(self):
        return 'WolterWavelet2021Raw'

    def __init__(self, opt):
        super(WolterWaveletRawTrainer, self).__init__(opt)

        # Wavelet packet parameters
        self.wavelet_type = getattr(opt, 'wavelet_type', 'haar')
        self.wavelet_level = getattr(opt, 'wavelet_level', 3)
        self.wavelet_mode = getattr(opt, 'wavelet_mode', 'reflect')
        self.use_log_packets = getattr(opt, 'use_log_packets', True)
        self._wavelet_backend_name = getattr(opt, 'wavelet_backend', 'cpu')
        self._gpu_wavelet = None  # lazy-init

        # Calculate number of input channels
        # At level 3: 4^3 = 64 packets per channel
        # For RGB: 3 * 64 = 192 channels
        num_packets_per_channel = 4 ** self.wavelet_level
        input_channels = 3 * num_packets_per_channel

        # Create model
        if self.isTrain and not opt.continue_train:
            self.model = WaveletPacketCNN(
                input_channels=input_channels,
                num_classes=1
            )
            init_weights(self.model, init_type='normal', gain=opt.init_gain)

        if not self.isTrain or opt.continue_train:
            self.model = WaveletPacketCNN(
                input_channels=input_channels,
                num_classes=1
            )

        if self.isTrain:
            self.loss_fn = nn.BCEWithLogitsLoss()

            # Initialize optimizer
            if opt.optim == 'adam':
                self.optimizer = torch.optim.Adam(
                    self.model.parameters(),
                    lr=opt.lr,
                    betas=(opt.beta1, 0.999),
                    weight_decay=1e-4
                )
            elif opt.optim == 'sgd':
                self.optimizer = torch.optim.SGD(
                    self.model.parameters(),
                    lr=opt.lr,
                    momentum=0.9,
                    weight_decay=1e-4
                )
            else:
                raise ValueError("optim should be [adam, sgd]")

        # Load checkpoint if needed
        if not self.isTrain:
            self.load_networks(opt.epoch)

        self.model.to(self.device)

    def _get_gpu_wavelet_backend(self):
        """Lazy-init the GPU wavelet backend on first use."""
        if self._gpu_wavelet is None:
            from data.wavelets.backends.gpu_backend import GPUWaveletBackend
            self._gpu_wavelet = GPUWaveletBackend(
                wavelet=self.wavelet_type,
                level=self.wavelet_level,
                mode=self.wavelet_mode,
                log_scale=self.use_log_packets,
                log_mode=getattr(self.opt, 'wavelet_log_mode', 'signed_log1p'),
                device=self.device,
            )
        return self._gpu_wavelet

    def adjust_learning_rate(self, min_lr=1e-6):
        for param_group in self.optimizer.param_groups:
            param_group['lr'] /= 10.
            if param_group['lr'] < min_lr:
                return False
        return True

    def __call__(self, input_tensor):
        """For validation - accepts wavelet packets from dataloader"""
        if input_tensor.shape[1] == 3 * 4 ** self.wavelet_level:  # Already wavelet packets
            output = self.model(input_tensor.to(self.device))
            return output

        # Fallback: compute wavelets if RGB input
        if self._wavelet_backend_name == 'gpu':
            backend = self._get_gpu_wavelet_backend()
            wavelet_input = backend(input_tensor.to(self.device))
        else:
            batch_packets = []
            for img in input_tensor:
                packets = compute_wavelet_packet_coeffs(
                    img, self.wavelet_type, self.wavelet_level, self.wavelet_mode
                )
                if self.use_log_packets:
                    packets = log_scale_packets(packets)
                batch_packets.append(packets)
            wavelet_input = torch.stack(batch_packets).to(self.device)

        output = self.model(wavelet_input)
        return output

    def train(self):
        self.model.train()

    def eval(self):
        self.model.eval()

    def set_input(self, input):
        """
        Input from dataloader: (tensor, labels).

        If tensor has 3 channels (RGB), computes wavelet packets on GPU
        for the entire batch.  If 192 channels, uses them directly.
        """
        data, labels = input[0], input[1]
        data = data.to(self.device)
        self.label = labels.to(self.device).float()

        if data.shape[1] == 3:
            # RGB input — compute wavelets on GPU in batch
            backend = self._get_gpu_wavelet_backend()
            with torch.no_grad():
                self.input = backend(data)
        else:
            # Already wavelet packets (192 channels)
            self.input = data

    def forward(self):
        self.output = self.model(self.input)

    def get_loss(self):
        return self.loss_fn(self.output.squeeze(1), self.label)

    def optimize_parameters(self):
        self.forward()
        self.loss = self.loss_fn(self.output.squeeze(1), self.label)
        self.optimizer.zero_grad()
        self.loss.backward()
        self.optimizer.step()

