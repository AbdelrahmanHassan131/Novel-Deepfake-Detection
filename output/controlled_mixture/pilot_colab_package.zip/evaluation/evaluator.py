"""
Model Evaluator Orchestrator.

Architecture-agnostic evaluation pipeline orchestrator that integrates:
- Checkpoint loading & model building (`CheckpointLoader`)
- Inference execution (`InferenceRunner`)
- Metrics calculation (`ClassificationMetrics`, `PerformanceProfiler`)
- Visualizations (ROC, PR, CM, t-SNE)
- Report generation (`EvaluationReportGenerator`)

Usage::

    from evaluation import Evaluator

    evaluator = Evaluator(
        checkpoint_path='experiments/model_best.pth',
        dataroot='dataset/val',
        output_dir='eval_output'
    )
    result = evaluator.run()
"""

import os
import torch
from .checkpoint_loader import CheckpointLoader
from .inference import InferenceRunner
from .metrics.classification import ClassificationMetrics
from .metrics.performance import PerformanceProfiler
from .reports.generator import EvaluationReportGenerator
from .visualization.roc import plot_evaluation_roc_curve
from .visualization.precision_recall import plot_evaluation_pr_curve
from .visualization.confusion_matrix import plot_evaluation_confusion_matrix
from .visualization.tsne import plot_tsne


class EvaluationResult:
    """Structured result container returned by Evaluator.run()."""

    def __init__(self, metadata, metrics, performance, inference_result,
                 plot_paths, report_paths):
        self.metadata = metadata
        self.metrics = metrics
        self.performance = performance
        self.inference_result = inference_result
        self.plot_paths = plot_paths
        self.report_paths = report_paths

    def __repr__(self):
        acc = self.metrics.get('accuracy', 0.0)
        auc = self.metrics.get('roc_auc', 0.0)
        return (
            f"EvaluationResult(arch='{self.metadata.get('arch')}', "
            f"accuracy={acc:.4f}, roc_auc={auc:.4f})"
        )


class Evaluator:
    """
    Architecture-agnostic model evaluator.

    Args:
        checkpoint_path (str): Path to the model `.pth` checkpoint file.
        dataroot (str): Root directory of the evaluation dataset.
        output_dir (str): Directory where plots and reports will be saved.
        arch (str, optional): Override architecture detection.
        batch_size (int): Batch size for DataLoader.
        device (str, optional): Target device (e.g., 'cuda:0' or 'cpu').
        collect_embeddings (bool): Whether to collect feature embeddings for t-SNE.
        run_profiling (bool): Whether to run performance profiling (FLOPs/latency).
        generate_plots (bool): Whether to generate ROC, PR, CM, and t-SNE plots.
    """

    def __init__(self, checkpoint_path, dataroot, output_dir='evaluation_results',
                 arch=None, batch_size=32, device=None, collect_embeddings=True,
                 run_profiling=True, generate_plots=True, generate_gradcam=True,
                 tsne_dataroot=None):
        self.checkpoint_path = checkpoint_path
        self.dataroot = dataroot
        self.output_dir = output_dir
        self.arch = arch
        self.batch_size = batch_size
        self.device = device or ('cuda:0' if torch.cuda.is_available() else 'cpu')
        self.collect_embeddings = collect_embeddings
        self.run_profiling = run_profiling
        self.generate_plots = generate_plots
        self.generate_gradcam = generate_gradcam
        self.tsne_dataroot = tsne_dataroot

        os.makedirs(self.output_dir, exist_ok=True)

    def run(self, opt_overrides=None):
        """
        Execute the full evaluation pipeline.

        Args:
            opt_overrides (dict, optional): Custom options to override during load/dataloading.

        Returns:
            EvaluationResult: Complete evaluation findings, plots, and reports.
        """
        print(f"=== Starting Evaluation Pipeline ===")
        print(f"Checkpoint: {self.checkpoint_path}")
        print(f"Dataset:    {self.dataroot}")
        print(f"Output dir: {self.output_dir}")

        # 1. Load Checkpoint and Build Model
        loader = CheckpointLoader(
            checkpoint_path=self.checkpoint_path,
            arch=self.arch,
            device=self.device
        )
        overrides = {'dataroot': self.dataroot or self.tsne_dataroot, 'batch_size': self.batch_size}
        if opt_overrides:
            overrides.update(opt_overrides)

        model = loader.load(opt_overrides=overrides)
        metadata = loader.metadata
        detected_arch = metadata.get('arch', 'unknown')

        if not self.dataroot and self.tsne_dataroot:
            print("[Evaluator] No --val_root provided; running dedicated multi-category t-SNE evaluation only.")
            plots_dir = os.path.join(self.output_dir, 'plots')
            os.makedirs(plots_dir, exist_ok=True)
            tsne_path = self._run_tsne_multi_folder(model, detected_arch, plots_dir)
            plot_paths = {'tsne': tsne_path} if tsne_path else {}
            return EvaluationResult(
                metadata=metadata,
                metrics={},
                performance={},
                inference_result=None,
                plot_paths=plot_paths,
                report_paths={}
            )

        threshold = 0.5
        threshold_file = (opt_overrides or {}).get('threshold_file')
        if threshold_file:
            import json
            from evaluation.generalization import ALLOWED_CALIBRATION_SPLITS, FORBIDDEN_CALIBRATION_SPLITS
            with open(threshold_file, encoding='utf-8') as stream:
                calibration = json.load(stream)
            if calibration['checkpoint_sha256'] != metadata.get('checkpoint_sha256'):
                raise ValueError('Threshold was selected for a different checkpoint')
            source_splits = set(calibration.get('source_splits', []))
            if not source_splits or source_splits.intersection(FORBIDDEN_CALIBRATION_SPLITS) or (source_splits - ALLOWED_CALIBRATION_SPLITS):
                raise ValueError(f"Threshold must come from development data {sorted(ALLOWED_CALIBRATION_SPLITS)}, got {sorted(source_splits)}")
            threshold = float(calibration['threshold'])
            recorded_precision = calibration.get('eval_precision', 'unknown')
            if recorded_precision not in ('unknown', 'fp32'):
                raise ValueError('Standalone evaluation uses FP32. Recompute development predictions '
                                 'in FP32 before calibrating a matching threshold.')
        metadata['decision_threshold_source'] = threshold_file or 'fixed 0.5; no test calibration'
        # 2. Build Dataloader
        dataloader = self._build_dataloader(model.opt)

        # 3. Run Inference
        runner = InferenceRunner(
            model=model,
            dataloader=dataloader,
            device=self.device,
            collect_embeddings=self.collect_embeddings
        )
        inference_result = runner.run()

        # 4. Compute Classification Metrics
        print("Computing classification metrics...")
        metric_calc = ClassificationMetrics(threshold=threshold)
        metrics = metric_calc.compute_all(
            probabilities=inference_result.probabilities,
            labels=inference_result.labels
        )

        from evaluation.generalization import export_predictions, summarize
        import json
        records = dataloader.dataset.records
        inference_result.predictions = (inference_result.probabilities >= threshold).astype(float)
        export_predictions(os.path.join(self.output_dir, 'predictions.csv'), records,
                           inference_result.probabilities, metadata.get('checkpoint_sha256'),
                           logits=getattr(inference_result, 'logits', None), eval_precision='fp32')
        generalization = summarize(records, inference_result.probabilities, threshold,
                                  repeats=(opt_overrides or {}).get('bootstrap', 200),
                                  logits=getattr(inference_result, 'logits', None))
        generalization['checkpoint'] = metadata
        with open(os.path.join(self.output_dir, 'generalization_report.json'), 'w', encoding='utf-8') as stream:
            json.dump(generalization, stream, indent=2, allow_nan=False)
        metrics['balanced_accuracy'] = generalization['overall']['balanced_accuracy']
        # Profile all experts, not just the small fusion head.
        performance = {}
        if self.run_profiling:
            from evaluation.end_to_end_profile import profile_pipeline
            performance = profile_pipeline(model)

        # 6. Generate Visualizations
        plot_paths = {}
        if self.generate_plots:
            print("Generating evaluation plots...")
            plots_dir = os.path.join(self.output_dir, 'plots')
            os.makedirs(plots_dir, exist_ok=True)

            plot_paths['roc_curve'] = plot_evaluation_roc_curve(
                probabilities=inference_result.probabilities,
                labels=inference_result.labels,
                save_path=os.path.join(plots_dir, 'roc_curve.png'),
                title=f'{detected_arch} ROC Curve'
            )

            plot_paths['precision_recall_curve'] = plot_evaluation_pr_curve(
                probabilities=inference_result.probabilities,
                labels=inference_result.labels,
                save_path=os.path.join(plots_dir, 'precision_recall_curve.png'),
                title=f'{detected_arch} PR Curve'
            )

            plot_paths['confusion_matrix'] = plot_evaluation_confusion_matrix(
                probabilities=inference_result.probabilities,
                labels=inference_result.labels,
                save_path=os.path.join(plots_dir, 'confusion_matrix.png'),
                title=f'{detected_arch} Confusion Matrix', threshold=threshold
            )

            if self.collect_embeddings:
                if getattr(self, 'tsne_dataroot', None):
                    tsne_path = self._run_tsne_multi_folder(model, detected_arch, plots_dir)
                    if tsne_path:
                        plot_paths['tsne'] = tsne_path
                elif inference_result.embeddings is not None:
                    cat_names = getattr(dataloader.dataset, 'classes', None)
                    if not cat_names or len(cat_names) < 2:
                        cat_names = ['Real (0)', 'Fake (1)']
                    plot_paths['tsne'] = plot_tsne(
                        embeddings=inference_result.embeddings,
                        labels=inference_result.labels,
                        category_names=cat_names,
                        save_path=os.path.join(plots_dir, 'tsne_embeddings.png'),
                        title=f'{detected_arch} t-SNE Embeddings'
                    )

            if self.generate_gradcam:
                gc_path = self._generate_gradcam_explanations(
                    model=model,
                    dataloader=dataloader,
                    detected_arch=detected_arch,
                    plots_dir=plots_dir
                )
                if gc_path:
                    plot_paths['gradcam'] = gc_path

        # 7. Generate Reports
        print("Generating reports...")
        report_gen = EvaluationReportGenerator(output_dir=self.output_dir)
        report_paths = report_gen.generate(
            metadata=metadata,
            metrics=metrics,
            performance=performance,
            plot_paths=plot_paths,
            report_name='evaluation_report'
        )

        print(f"=== Evaluation Complete ===")
        print(f"Accuracy: {metrics.get('accuracy', 0):.4f} | ROC AUC: {metrics.get('roc_auc', 0):.4f}")
        print(f"Markdown Report: {report_paths['markdown']}")

        return EvaluationResult(
            metadata=metadata,
            metrics=metrics,
            performance=performance,
            inference_result=inference_result,
            plot_paths=plot_paths,
            report_paths=report_paths
        )

    def _build_dataloader(self, opt, target_root=None):
        """Build the appropriate DataLoader for the model architecture."""
        import copy
        from data import create_dataloader, create_mha_dataloader

        opt = copy.copy(opt)
        # Override with evaluation target settings
        opt.dataroot = target_root or self.dataroot
        opt.batch_size = self.batch_size
        opt.val_batch_size = self.batch_size
        opt.isTrain = False
        print(f"[Evaluator] Effective evaluation batch size: {self.batch_size}")
        print(f"[Evaluator] Precision: fp32; workers: {getattr(opt, 'val_num_workers', None) or getattr(opt, 'num_workers', 0)}")

        # Ensure opt has necessary dataset and transform defaults
        defaults = {
            'classes': ['0_real', '1_fake'],
            'mode': 'binary',
            'serial_batches': True,
            'class_bal': False,
            'num_threads': 0,
            'no_crop': False,
            'no_flip': True,
            'no_resize': False,
            'cropSize': 224,
            'loadSize': 256,
            'rz_interp': ['bilinear'],
            'blur_prob': 0.0,
            'blur_sig': [0.5],
            'jpg_prob': 0.0,
            'jpg_method': ['cv2'],
            'jpg_qual': [75],
            'data_aug': False,
            'wavelet_backend': 'gpu' if torch.cuda.is_available() else 'cpu',
            'wavelet_type': 'haar',
            'level': 3,
            'precomputed_dir': None,
            'rgb_model_path': getattr(opt, 'rgb_model_path', ''),
            'wavelet_model_path': getattr(opt, 'wavelet_model_path', ''),
        }
        for k, v in defaults.items():
            if not hasattr(opt, k) or (k == 'classes' and not getattr(opt, k)):
                setattr(opt, k, v)

        # MHA/Fusion multi-input loaders
        arch = getattr(opt, 'arch', '')
        if arch in ('Fusion_128', 'MHA_128', 'Fusion_WWXC', 'MHA_WWXC'):
            dataloader = create_mha_dataloader(opt)
        else:
            dataloader = create_dataloader(opt)

        self._log_dataset_label_mapping(dataloader.dataset)
        return dataloader

    def _log_dataset_label_mapping(self, dataset):
        """Log dataset class mapping to preserve native ImageFolder order used during training."""
        if hasattr(dataset, 'datasets'):
            for d in dataset.datasets:
                self._log_dataset_label_mapping(d)
            return

        if hasattr(dataset, 'class_to_idx'):
            print(f"[Evaluator] Dataset class mapping: {dataset.class_to_idx}")

    def _run_tsne_multi_folder(self, model, detected_arch, plots_dir):
        """Run dedicated t-SNE feature embedding extraction and visualization on a multi-folder dataset."""
        if not self.tsne_dataroot or not os.path.exists(self.tsne_dataroot):
            print(f"[WARNING] t-SNE multi-folder validation dataset not found: {self.tsne_dataroot}")
            return None
        from evaluation.inference import InferenceRunner
        from evaluation.visualization.tsne import plot_tsne

        print(f"\n[t-SNE] Extracting embeddings from multi-folder t-SNE dataset: {self.tsne_dataroot}")
        tsne_loader = self._build_dataloader(model.opt, target_root=self.tsne_dataroot)
        discovered_classes = getattr(tsne_loader.dataset, 'classes', None)
        if not discovered_classes:
            discovered_classes = [f'Class {i}' for i in range(100)]
        print(f"[t-SNE] Discovered {len(discovered_classes)} category subfolders: {discovered_classes}")

        runner = InferenceRunner(
            model=model,
            dataloader=tsne_loader,
            device=self.device,
            collect_embeddings=True
        )
        tsne_result = runner.run()
        if tsne_result.embeddings is None or len(tsne_result.embeddings) == 0:
            print("[WARNING] Could not extract embeddings for t-SNE.")
            return None

        return plot_tsne(
            embeddings=tsne_result.embeddings,
            labels=tsne_result.labels,
            category_names=discovered_classes,
            save_path=os.path.join(plots_dir, 'tsne_embeddings.png'),
            title=f'{detected_arch} Multi-Generator t-SNE ({len(discovered_classes)} Categories)'
        )

    def _generate_gradcam_explanations(self, model, dataloader, detected_arch, plots_dir):
        """Generate sample Grad-CAM heatmap visualization figure."""
        try:
            from .visualization.gradcam import GradCAM, generate_gradcam_figure
        except ImportError:
            return None

        raw_net = getattr(model, 'model', model)
        target_layer = None
        for m in raw_net.modules():
            if isinstance(m, torch.nn.Conv2d):
                target_layer = m

        if target_layer is None:
            print(f"[Evaluator] No Conv2d layer found in {detected_arch} for Grad-CAM.")
            return None

        images = []
        cams = []
        labels = []
        predictions = []

        cam_engine = GradCAM(model, target_layer)
        try:
            for batch in dataloader:
                if len(images) >= 6:
                    break
                inputs, targets = batch[0], batch[1]
                for i in range(inputs.size(0)):
                    if len(images) >= 6:
                        break
                    inp = inputs[i:i+1].to(self.device)
                    lbl = int(targets[i].item())

                    img_tensor = inputs[i].cpu()
                    mean = torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1)
                    std = torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1)
                    img_unnorm = torch.clamp(img_tensor * std + mean, 0, 1)
                    img_np = img_unnorm.permute(1, 2, 0).numpy()

                    heatmap, out_tensor = cam_engine.generate(inp)
                    prob = float(torch.sigmoid(out_tensor).squeeze().item())

                    images.append(img_np)
                    cams.append(heatmap)
                    labels.append(lbl)
                    predictions.append(prob)
        except Exception as e:
            print(f"[Evaluator] Note: Grad-CAM generation skipped ({e})")
        finally:
            cam_engine.remove_hooks()

        if not images:
            return None

        save_path = os.path.join(plots_dir, 'gradcam_explanations.png')
        generate_gradcam_figure(
            images=images,
            cams=cams,
            labels=labels,
            predictions=predictions,
            save_path=save_path,
            title=f"{detected_arch} Grad-CAM Explanations"
        )
        return save_path
